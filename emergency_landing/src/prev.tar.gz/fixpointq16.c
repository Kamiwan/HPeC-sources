/*************************************************************************************
 * File   : fixpointq16.c, file for Vision Based Autonomous Landing
 *
 * Copyright (C) 2016 Lab-Sticc Laboratory
 * Author(s) :  Dominique Heller, dominique.heller@univ-ubs.fr     
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *************************************************************************************/
#include "fixpointq16.h"
#include <math.h>

/*  counts the number of zero bits preceding the most significant one bit */
int32_t countleadingzeros(uint32_t x)
{
        uint32_t exp = 31;
        if (x & 0xffff0000)
        {
             exp -= 16;
             x >>= 16;
        }
        if (x & 0xff00)
        {
           exp -= 8;
           x >>= 8;
        }
        if (x & 0xf0)
        {
           exp -= 4;
           x >>= 4;
        }
        if (x & 0xc)
        {
           exp -= 2;
           x >>= 2;
        }
        if (x & 0x2)
        {
           exp -= 1;
        }
        return exp;
}

/* 16Q16 multiply */
int32_t fixmul16(int32_t a,int32_t b)
{
        int64_t prod;
        prod = (int64_t)a * b;
        return (int32_t)(prod >>16);
}

/* 16Q16 Reciprocal  based on Newton-Raphson method */
int32_t fixinv16(int32_t a)
{
  static const int32_t two=2<<16;
  static const uint16_t rcp_tab[] = {0x8000, 0x71c7, 0x6666, 0x5d17, 0x5555, 0x4ec4, 0x4924, 0x4444};
  int32_t x,exp,ax,twominusax;
  uint8_t sign = 0;
  if (a < 0)
  {
     sign = 1;
     a = -a;
  }
  exp = countleadingzeros(a);
  x = ((int32_t)rcp_tab[(a>>(28-exp))&0x7]) << 2;
  exp -= 16;
  if (exp <= 0)
        x >>= -exp;
  else
        x <<= exp;
  /* two iterations of newton-raphson  x = x(2-ax) */
   ax=fixmul16(a,x);
   twominusax=two -ax;
   x = fixmul16(x,twominusax);
   ax=fixmul16(a,x);
   twominusax=two -ax;
   x = fixmul16(x,twominusax);
   if (sign)
        return -x;
   else
         return x;
}

/* 16Q16 Reciprocal Square root based on Newton-Raphson method */
int32_t fixrsqrt16(int32_t a)
{
  static const int32_t three=3<<16;
  int32_t x;
  static const uint16_t rsq_tab[] = { /* domain 0.5 .. 1.0-1/16 */
         0xb504, 0xaaaa, 0xa1e8, 0x9a5f, 0x93cd, 0x8e00, 0x88d6, 0x8432,     };
  int32_t i, exp;
  int32_t ax,axx,threeminusaxx,xdiv2;

  if (a == 0) return 0x7fffffff;
  if (a == (1<<16)) return a;
  //reduction
  exp = countleadingzeros(a);
  x = rsq_tab[(a>>(28-exp))&0x7]<<1;
  exp -= 16;
  if (exp <= 0)
       x >>= -exp>>1;
  else
       x <<= (exp>>1)+(exp&1);
  if (exp&1) x = fixmul16(x, rsq_tab[0]);
  /* newton-raphson :  x = x/2*(3-(a*x)*x) */
  for (i=0;i<3;i++)
  {
    ax=fixmul16(a,x);
    axx=fixmul16(ax,x);
    threeminusaxx=three- axx;
    xdiv2=x>>1;
    x = fixmul16(xdiv2,threeminusaxx);
   }
   return x;
 }


int32_t fastfixsqrt16(int32_t a)
{
	int32_t rsqrt16=fixrsqrt16(a);
	int32_t sqrt16=FIXMUL(a,rsqrt16);
	return sqrt16;
}

int32_t fixsqrt16(int32_t a)
{
    //double floatvalue=fix2float(a),sqrtvalue;
    float floatvalue=fix2float(a),sqrtvalue;
	sqrtvalue=sqrt(floatvalue);
	return float2fix(sqrtvalue);
}


/* division */
int32_t fastdiv16(int32_t a, int32_t b)
{
  int32_t inv;
  int32_t result;

  if ((b >> 24) && (b >> 24) + 1)
  {
    inv=fixinv16(b >> 8);
    result=fixmul16(a >> 8,inv);
  }
  else
  {
    inv=fixinv16(b);
    result=fixmul16(a,inv);
  }
  return result;
}

int f16Q16Round(f16Q16 a)
{
	return fix2Int(a+f16Q16half);
}

int f32Q32Round(f32Q32 a)
{
	return f32Q322Int(a+f32Q32half);
}

int32_t fixmul_macro(int32_t a, int32_t b)
{ 
	register int32_t result;
	if ((a==0) || (b==0)) 
		result=0;
	else
	{
		//putfsl(a, 0);putfsl(b, 0);getfsl(result, 0);
		result=FIXMUL64(a,b);
	}
	return result;
}



/* 16Q16 NIIRF method 
	yn+1= yn + Beta *(x-yn*yn)
	Beta is initalized using beta = 2 * x /+ 0.354167 
	and normalization of x 0.25<<x<1.
	Beta is stored in LUT with x between 4/16 and 16/16 and a step of 1/16 

  if x<0.5, x is multiplied by 4^n ((<<2) until 0.25<x<1
  if x>1.0 x is divided by 4^n ((>>2)  until 0.25<x<1
  the final square root result is denormalized by a factor of 2^n


  TO_TEST
int64_t fixsqrt32_2(int64_t a)
{
 }

  */


