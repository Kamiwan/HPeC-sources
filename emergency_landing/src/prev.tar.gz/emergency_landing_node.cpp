#include <ros/ros.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <image_transport/image_transport.h>
extern"C"{
	#include "image.h"
}

#include <sensor_msgs/NavSatFix.h>
#include <sensor_msgs/image_encodings.h>

#include <ros/callback_queue.h>
#include <boost/thread.hpp>
#include "std_msgs/Int32.h"

double diameter;
double altitude;
double camera_angle;
double image_height;
PPM_IMG img_ibuf_color;

void gps_callback(const sensor_msgs::NavSatFix::ConstPtr& position);

void image_callback(const sensor_msgs::Image::ConstPtr& image_cam);



bool run = false;
int current_ver = 0;
boost::shared_ptr<boost::thread> worker_thread = NULL ;
boost::shared_ptr<ros::NodeHandle> workerHandle_ptr = NULL;


void emergency_landing_all_soft_thread (const boost::shared_ptr<ros::NodeHandle> & workerHandle_ptr)
{
  ROS_ERROR("[THREAD][RUNNING]");
  
  run = true;
  ros::CallbackQueue queue;
  workerHandle_ptr->setCallbackQueue(&queue);
  
	
	double rate_double;
	if (!workerHandle_ptr->getParam("/node_activation_rates/emergency_landing", rate_double))
	{
		ROS_ERROR("Could not read obstacle detection's activation rate. Setting 1 Hz");
		rate_double = 1;
	}
	ros::Rate rate(rate_double);
	
	if (!workerHandle_ptr->getParam("/drone_features/diameter", diameter))
	{
		ROS_ERROR("Could not read drone's diameter. Setting to 0.6 meters");
		diameter=0.6;
	}
	
	if (!workerHandle_ptr->getParam("/camera_features/camera_angle", camera_angle))
	{
		ROS_ERROR("Could not read camera's angle. Setting to 0.4 radian");
		camera_angle=0.4;
	}
	
	if (!workerHandle_ptr->getParam("/camera_features/image_height", image_height))
	{
		ROS_ERROR("Could not read image's height. Setting to 480");
		image_height=480;
	}
	
	altitude =60;
	img_ibuf_color = read_ppm("/home/ubuntu/sim_cam/test2.ppm");
	
	ros::Subscriber gps_sub = workerHandle_ptr->subscribe("mavros/global_position/global",1,gps_callback);	
	image_transport::ImageTransport it(*workerHandle_ptr);
	image_transport::Subscriber cam_sub=it.subscribe("usb_cam/image_raw", 1, image_callback);
	
	while(workerHandle_ptr->ok())
	{
	       queue.callAvailable();		
		PGM_IMG img_ibuf_g;
		PGM_IMG img_ibuf_ceh;
		PGM_IMG img_ibuf_me1;
		PGM_IMG img_ibuf_me;
		PGM_IMG img_ibuf_bw;
		PGM_IMG img_ibuf_ccl;
		PGM_IMG img_ibuf_mop;
		PGM_IMG img_ibuf_mop2;
		PGM_IMG img_ibuf_mop3;
		PGM_IMG img_ibuf_ero;
		PGM_IMG img_ibuf_gs;
		PGM_IMG img_ibuf_sp;
		PGM_IMG img_ibuf_zon;
		PGM_IMG img_ibuf_se;
		PGM_IMG img_ibuf_ms;
		int nb_labels;
		COMPONENT *ccl;
		
		img_ibuf_g = rgb2gray(img_ibuf_color);
		
		img_ibuf_me1=medianfilter(img_ibuf_g);
		free_pgm(img_ibuf_g);
		
		img_ibuf_me=medianfilter(img_ibuf_me1);
		free_pgm(img_ibuf_me1);
		
		img_ibuf_gs=gaussianfilter(img_ibuf_me);
		free_pgm(img_ibuf_me);
		
		img_ibuf_sp.w = img_ibuf_gs.w;
		img_ibuf_sp.h = img_ibuf_gs.h;
		img_ibuf_sp.img = (unsigned char *)malloc(img_ibuf_sp.w * img_ibuf_sp.h * sizeof(unsigned char));
		img_ibuf_se.w = img_ibuf_gs.w;
		img_ibuf_se.h = img_ibuf_gs.h;
		img_ibuf_se.img = (unsigned char *)malloc(img_ibuf_se.w * img_ibuf_se.h * sizeof(unsigned char));
		sobel(img_ibuf_gs,img_ibuf_sp,img_ibuf_se);
		free_pgm(img_ibuf_gs);
		
		img_ibuf_ms=canny(img_ibuf_sp,img_ibuf_se,20,80);
		free_pgm(img_ibuf_sp);
		free_pgm(img_ibuf_se);
		
		img_ibuf_mop=dilate(img_ibuf_ms);
		free_pgm(img_ibuf_ms);
		
		img_ibuf_mop2=dilate(img_ibuf_mop);
		free_pgm(img_ibuf_mop);
		
		img_ibuf_mop3=dilate(img_ibuf_mop2);
		free_pgm(img_ibuf_mop2);
			
		img_ibuf_ero=erode(img_ibuf_mop3);
		free_pgm(img_ibuf_mop3);
		
		int size_zone=ceil(diameter*image_height/(2*altitude*tan(camera_angle)));
		img_ibuf_zon=zone(img_ibuf_ero,size_zone);
		free_pgm(img_ibuf_ero);
				
		img_ibuf_ccl=connected_component_labeling(img_ibuf_zon,&nb_labels,&ccl,200,100000);
		free_pgm(img_ibuf_zon);
		
    		write_pgm(img_ibuf_ccl, "/home/ubuntu/ccl.pgm");
		free_pgm(img_ibuf_ccl);		
		rate.sleep();
    	} run = false ;
	ROS_ERROR("[THREAD][STOPPED]");
}


void stop ( ) 
{
  if(workerHandle_ptr == NULL && worker_thread == NULL) return ;
  if(workerHandle_ptr != NULL) workerHandle_ptr->shutdown ();
  if(worker_thread !=  NULL) {
    worker_thread->timed_join(boost::posix_time::seconds(1));
    if(run)  pthread_cancel(worker_thread->native_handle());
  }
  // RESET
  workerHandle_ptr = NULL;
  worker_thread = NULL;    
}



void managing_controller_request (const std_msgs::Int32::ConstPtr& value)
{
  switch (value->data){
  case 0 : // stop
    stop ( ) ;
    break;
    
  case 1 : //start   
    stop ( ) ;
    workerHandle_ptr = boost::make_shared<ros::NodeHandle>();
    worker_thread =  boost::make_shared<boost::thread>(&emergency_landing_all_soft_thread, workerHandle_ptr);
    break;
    
  default:
    break;
  }
}


int main (int argc, char ** argv)
{
	ros::init(argc, argv, "emergency_landing_node");
	ros::NodeHandle nh;
	
	ros::Subscriber mgt_topic;
	mgt_topic = nh.subscribe("controller_outputs", 1, managing_controller_request);
	ros::spin();
}

void gps_callback(const sensor_msgs::NavSatFix::ConstPtr& position)
{
	altitude = position->altitude;
}

void image_callback(const sensor_msgs::Image::ConstPtr& image_cam)
{
	//img_ibuf_color.h=image_cam->height;
	//img_ibuf_color.w=image_cam->width;
	//img_ibuf_color.img=image_cam->data;
}
