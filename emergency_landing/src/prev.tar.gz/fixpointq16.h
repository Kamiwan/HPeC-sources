/*************************************************************************************
 * File   : fixpointq16.h, file for Vision Based Autonomous Landing
 *
 * Copyright (C) 2016 Lab-Sticc Laboratory
 * Author(s) :  Dominique Heller, dominique.heller@univ-ubs.fr     
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *************************************************************************************/
#ifndef FIXPOINT16Q16_H
#define FIXPOINT16Q16_H
#include "stdint.h"
#define f16Q16 int32_t
#define f32Q32 int64_t
#define FractPart 16
#define f16Q16ScaleFactor (1<<FractPart)
#define f16Q16half (1<<15)
#define f32Q32ScaleFactor (1ULL<<32)
#define f32Q32half (1ULL<<31)
#define float2fix(a) ((int32_t)((a)*f16Q16ScaleFactor))
//#define fix2float(a) ((double)(a)/f16Q16ScaleFactor)
#define fix2float(a) ((float)(a)/f16Q16ScaleFactor)
#define fix32Q322float(a) ((long double)(a)/f32Q32ScaleFactor)
#define float2fix32Q32(a) ((int64_t)((a)*f32Q32ScaleFactor))
#define fix2Int(a) ((a)/f16Q16ScaleFactor)
#define int2fix(a) (a<<FractPart)
#define f32Q322Int(a) ((a)/f32Q32ScaleFactor)
#define FIXMUL64(a,b) ((f16Q16)(((int64_t)(a)*(b))>>FractPart))
#define FIXMUL(a,b) fixmul_macro(a,b)

int32_t countleadingzeros(uint32_t x);
int32_t fixmul16(int32_t a,int32_t b);
int32_t fixinv(int32_t a);
int32_t fixrsqrt16(int32_t a);
int32_t fixsqrt16(int32_t a);
int32_t fastfixsqrt16(int32_t a);
int32_t fastdiv16(int32_t a, int32_t b);
int64_t fixsqrt32(int64_t a);
int f16Q16Round(f16Q16 a);
int f32Q32Round(f32Q32 a);
int32_t fixmul_macro(int32_t a, int32_t b);

#endif
