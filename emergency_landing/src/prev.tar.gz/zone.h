#ifndef ZONE_H
#define ZONE_H
void zone_detecting(unsigned char * img_in, unsigned char * img_out, int size);
void erase(unsigned char * img_in);
int max(int a,int b);
void square(unsigned char * img_in, int size, int i, int j);
#endif
